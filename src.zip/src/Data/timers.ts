export const TIMER_CONFIG = {
  banSeconds: 30, // per ban, host-controlled clock
  draftSeconds: 45, // per pick, host-controlled clock
  squadSeconds: 60, // per player, to select their 3-agent squad
  scoreTotalSeconds: 8 * 60, // total time to submit a score
  scoreSuddenDeathSeconds: 2 * 60, // cap applied to the OTHER player once one player locks in
};

// How many rounds a used agent stays on cooldown (unselectable in Squad
// Select) before becoming available again. A future modifier that changes
// cooldown length would change this value (or apply a per-agent override).
export const COOLDOWN_ROUNDS = 1;
